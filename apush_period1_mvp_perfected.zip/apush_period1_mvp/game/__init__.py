"""APUSH Period 1 historical strategy simulator."""
